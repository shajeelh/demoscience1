import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.KeyFactory;
import java.security.cert.CertificateFactory;
import java.security.spec.MGF1ParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.Properties;

/**
 * Java 8 executable example: encrypt JSON -> OAuth-sign encrypted body -> POST
 * -> decrypt response. Only external dependency: Gson 2.13.2 (JSON parsing).
 * All cryptography and HTTP use standard Java APIs; no Mastercard SDK required.
 */
public final class MastercardCrossBorder {
    private static final Gson JSON = new GsonBuilder().disableHtmlEscaping().create();
    private static final Properties CONFIG = new Properties();
    private static Path configDirectory;
    private static final SecureRandom RANDOM = new SecureRandom();
    // Important: Java's OAEP SHA-256 transformation may otherwise default MGF1 to SHA-1.
    private static final OAEPParameterSpec OAEP = new OAEPParameterSpec(
            "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--self-test".equals(args[0])) {
            selfTest();
            return;
        }
        if (args.length < 2 || args.length > 3 || (args.length == 3 && !"--check-config".equals(args[2]))) {
            throw new IllegalArgumentException("Usage: java -jar MastercardCrossBorder.jar <properties-file> <partner-id> [--check-config]");
        }
        if (Cipher.getMaxAllowedKeyLength("AES") < 256) {
            throw new IllegalStateException("AES-256 requires unlimited crypto policy (enabled by default in Java 8u161+).");
        }

        // UTF-8 properties file; relative key paths resolve beside this file.
        Path configFile = Paths.get(args[0]).toAbsolutePath().normalize();
        String partnerId = args[1];
        Properties profiles = new Properties();
        try (java.io.Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) { profiles.load(reader); }
        selectPartner(profiles, partnerId);
        configDirectory = configFile.getParent();
        Path keyDirectory = configDirectory.resolve(Paths.get(property("MC_KEYS_DIR", "."))).normalize();
        String consumerKey = requiredProperty("MC_CONSUMER_KEY");
        PrivateKey signingKey = privateKey("MC_SIGNING_PRIVATE_KEY_PEM",
                keyDirectory.resolve(property("MC_SIGNING_P12", "")),
                property("MC_SIGNING_ALIAS", "mastercardkey"), "MC_KEY_PASSWORD");
        PrivateKey responseKey = privateKey("MC_DECRYPTION_PRIVATE_KEY_PEM",
                keyDirectory.resolve(property("MC_DECRYPTION_P12", "")),
                property("MC_DECRYPTION_ALIAS", ""), "MC_DECRYPTION_PASSWORD");
        PublicKey encryptionKey;
        Path certificate = keyDirectory.resolve(property("MC_ENCRYPTION_CERT", ""));
        String publicPem = property("MC_ENCRYPTION_PUBLIC_KEY_PEM", "");
        if (!publicPem.isEmpty()) {
            byte[] der = Base64.getDecoder().decode(publicPem.replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "").replaceAll("\\s", ""));
            encryptionKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(der));
        } else {
            try (InputStream input = Files.newInputStream(certificate)) {
                encryptionKey = CertificateFactory.getInstance("X.509").generateCertificate(input).getPublicKey();
            }
        }
        // Portal fingerprint = SHA-256 of DER SubjectPublicKeyInfo, NOT certificate DER.
        String keyId = property("MC_ENCRYPTION_KEY_ID", hex(sha256(encryptionKey.getEncoded())));
        if (args.length == 3 && "--check-config".equals(args[2])) {
            System.out.println("PASS: properties and RSA keys loaded for partner " + partnerId + "; no API call made.");
            return;
        }
        String transactionReference = property("MC_TRANSACTION_REFERENCE", "java" + UUID.randomUUID().toString().replace("-", ""));

        // Change this JSON string to the payload you want to send.
        // For a payment using a quote, retain that quote's reference and proposal ID.
        String requestPayloadJson = "{\"quoterequest\":{"
                + "\"transaction_reference\":" + JSON.toJson(transactionReference) + ","
                + "\"sender_account_uri\":\"ewallet:payorID123456;sp=MTO#456\","
                + "\"recipient_account_uri\":\"ban:30056001140114000251817;bic=CCFRFRPP\","
                + "\"payment_amount\":{\"amount\":\"192.64\",\"currency\":\"USD\"},"
                + "\"payment_origination_country\":\"USA\",\"payment_type\":\"P2P\","
                + "\"quote_type\":{\"forward\":{\"fees_included\":\"true\",\"receiver_currency\":\"GBP\"}}}}";
        JsonParser.parseString(requestPayloadJson); // Fail early for malformed JSON.

        URI uri = new URI("https://sandbox.api.mastercard.com/send/v1/partners/"
                + percentEncode(partnerId) + "/crossborder/quotes?Format=JSON");
        String method = "POST";

        // 1. Encrypt plaintext JSON, then wrap its compact JWE.
        String encryptedRequestJson = encryptPayload(requestPayloadJson, encryptionKey, keyId);
        // 2. Sign the EXACT encrypted JSON bytes that will be transmitted.
        String authorization = authorizationHeader(uri, method, encryptedRequestJson, consumerKey, signingKey);
        // 3. Send the request. TLS validation stays enabled; redirects are disabled.
        HttpsURLConnection connection = (HttpsURLConnection) uri.toURL().openConnection();
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(45000);
            connection.setRequestMethod(method);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("x-encrypted", "true");
            connection.setRequestProperty("Authorization", authorization);
            byte[] wireBody = utf8(encryptedRequestJson);
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(wireBody.length);
            try (OutputStream output = connection.getOutputStream()) { output.write(wireBody); }
            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            String response = stream == null ? "" : readUtf8(stream);
            // 4. Decrypt encrypted success responses; leave plaintext API errors intact.
            String clearResponse = response.isEmpty() ? "" : decryptResponse(response, responseKey);
            System.out.println("Transaction reference: " + transactionReference);
            System.out.println("HTTP " + status);
            System.out.println("Decrypted response (or plaintext error):");
            System.out.println(clearResponse);
            if (status < 200 || status >= 300) throw new IllegalStateException("Mastercard returned HTTP " + status);
        } finally {
            connection.disconnect();
        }
    }

    /** RSA-OAEP-256 + A256GCM compact JWE in Mastercard's JSON envelope. */
    public static String encryptPayload(String plaintext, PublicKey publicKey, String keyId) throws Exception {
        byte[] cek = new byte[32], iv = new byte[12];
        RANDOM.nextBytes(cek); RANDOM.nextBytes(iv);
        JsonObject header = new JsonObject();
        header.addProperty("alg", "RSA-OAEP-256"); header.addProperty("enc", "A256GCM");
        header.addProperty("cty", "application/json"); header.addProperty("kid", keyId);
        String protectedHeader = base64Url(utf8(JSON.toJson(header)));
        Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPPadding");
        rsa.init(Cipher.ENCRYPT_MODE, publicKey, OAEP);
        byte[] wrappedKey = rsa.doFinal(cek);
        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(cek, "AES"), new GCMParameterSpec(128, iv));
        aes.updateAAD(utf8(protectedHeader));
        byte[] ciphertextAndTag = aes.doFinal(utf8(plaintext));
        Arrays.fill(cek, (byte) 0);
        int tagOffset = ciphertextAndTag.length - 16;
        String jwe = protectedHeader + "." + base64Url(wrappedKey) + "." + base64Url(iv) + "."
                + base64Url(Arrays.copyOfRange(ciphertextAndTag, 0, tagOffset)) + "."
                + base64Url(Arrays.copyOfRange(ciphertextAndTag, tagOffset, ciphertextAndTag.length));
        JsonObject payload = new JsonObject(), envelope = new JsonObject();
        payload.addProperty("data", jwe); envelope.add("encrypted_payload", payload);
        return JSON.toJson(envelope);
    }

    /** Verify the GCM tag before returning plaintext. Accepts A128GCM/A256GCM responses. */
    public static String decryptResponse(String responseJson, PrivateKey privateKey) throws Exception {
        JsonObject envelope = JsonParser.parseString(responseJson).getAsJsonObject();
        if (!envelope.has("encrypted_payload")) return responseJson;
        String[] parts = envelope.getAsJsonObject("encrypted_payload").get("data").getAsString().split("\\.", -1);
        if (parts.length != 5) throw new IllegalArgumentException("Expected a five-part compact JWE");
        JsonObject header = JsonParser.parseString(new String(decode64Url(parts[0]), StandardCharsets.UTF_8)).getAsJsonObject();
        String alg = header.get("alg").getAsString(), enc = header.get("enc").getAsString();
        if (!"RSA-OAEP-256".equals(alg) || !("A128GCM".equals(enc) || "A256GCM".equals(enc))
                || header.has("crit") || header.has("zip")) throw new IllegalArgumentException("Unsupported JWE header");
        Cipher rsa = Cipher.getInstance("RSA/ECB/OAEPPadding");
        rsa.init(Cipher.DECRYPT_MODE, privateKey, OAEP);
        byte[] cek = rsa.doFinal(decode64Url(parts[1]));
        byte[] iv = decode64Url(parts[2]), ciphertext = decode64Url(parts[3]), tag = decode64Url(parts[4]);
        if (cek.length != ("A256GCM".equals(enc) ? 32 : 16) || iv.length != 12 || tag.length != 16)
            throw new IllegalArgumentException("Invalid JWE key, IV or tag length");
        byte[] combined = Arrays.copyOf(ciphertext, ciphertext.length + tag.length);
        System.arraycopy(tag, 0, combined, ciphertext.length, tag.length);
        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(cek, "AES"), new GCMParameterSpec(128, iv));
        aes.updateAAD(utf8(parts[0]));
        try { return new String(aes.doFinal(combined), StandardCharsets.UTF_8); }
        finally { Arrays.fill(cek, (byte) 0); }
    }

    /** Matches Mastercard's signer normalization, including its body-hash extension. */
    public static String authorizationHeader(URI uri, String method, String body, String consumerKey, PrivateKey key) throws Exception {
        Map<String, String> oauth = new TreeMap<String, String>();
        oauth.put("oauth_body_hash", Base64.getEncoder().encodeToString(sha256(utf8(body == null ? "" : body))));
        oauth.put("oauth_consumer_key", consumerKey);
        oauth.put("oauth_nonce", UUID.randomUUID().toString().replace("-", ""));
        oauth.put("oauth_signature_method", "RSA-SHA256");
        oauth.put("oauth_timestamp", Long.toString(System.currentTimeMillis() / 1000));
        oauth.put("oauth_version", "1.0");
        // Query components retain their existing percent encoding. OAuth values
        // remain raw here, as in Mastercard's signer, before whole-string encoding.
        List<String> pairs = new ArrayList<String>();
        if (uri.getRawQuery() != null && !uri.getRawQuery().isEmpty()) {
            for (String pair : uri.getRawQuery().split("&")) pairs.add(pair.contains("=") ? pair : pair + "=");
        }
        for (Map.Entry<String, String> entry : oauth.entrySet()) pairs.add(entry.getKey() + "=" + entry.getValue());
        Collections.sort(pairs, (a, b) -> {
            String ak = a.substring(0, a.indexOf('=')), bk = b.substring(0, b.indexOf('='));
            int order = ak.compareTo(bk);
            return order != 0 ? order : a.substring(a.indexOf('=') + 1).compareTo(b.substring(b.indexOf('=') + 1));
        });
        String host = uri.getHost().toLowerCase(java.util.Locale.ROOT);
        int port = uri.getPort();
        String scheme = uri.getScheme().toLowerCase(java.util.Locale.ROOT);
        if (port != -1 && !(port == 443 && "https".equals(scheme)) && !(port == 80 && "http".equals(scheme))) host += ":" + port;
        String path = uri.getRawPath().isEmpty() ? "/" : uri.getRawPath();
        String base = method.toUpperCase(java.util.Locale.ROOT) + "&" + percentEncode(scheme + "://" + host + path)
                + "&" + percentEncode(String.join("&", pairs));
        Signature signer = Signature.getInstance("SHA256withRSA");
        signer.initSign(key); signer.update(utf8(base));
        oauth.put("oauth_signature", percentEncode(Base64.getEncoder().encodeToString(signer.sign())));
        List<String> fields = new ArrayList<String>();
        for (Map.Entry<String, String> entry : oauth.entrySet()) fields.add(entry.getKey() + "=\"" + entry.getValue() + "\"");
        return "OAuth " + String.join(",", fields);
    }

    private static PrivateKey privateKey(String pemVariable, Path p12, String alias, String passwordVariable) throws Exception {
        String pem = CONFIG.getProperty(pemVariable);
        if (pem != null && !pem.isEmpty()) {
            byte[] der = Base64.getDecoder().decode(pem.replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "").replaceAll("\\s", ""));
            return KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(der));
        }
        String password = property(passwordVariable, property("MC_KEY_PASSWORD", ""));
        if (password.isEmpty()) throw new IllegalArgumentException("Set " + passwordVariable + " (or MC_KEY_PASSWORD)");
        char[] chars = password.toCharArray();
        try {
            KeyStore store = KeyStore.getInstance("PKCS12");
            try (InputStream input = Files.newInputStream(p12)) { store.load(input, chars); }
            if (alias.isEmpty()) {
                Enumeration<String> names = store.aliases();
                while (names.hasMoreElements()) {
                    String candidate = names.nextElement();
                    if (store.isKeyEntry(candidate)) {
                        if (!alias.isEmpty()) throw new IllegalArgumentException("Multiple private keys: set an explicit alias");
                        alias = candidate;
                    }
                }
            }
            java.security.Key key = store.getKey(alias, chars);
            if (!(key instanceof PrivateKey) || !"RSA".equals(key.getAlgorithm())) throw new IllegalArgumentException("RSA private key not found for alias " + alias);
            return (PrivateKey) key;
        } finally { Arrays.fill(chars, '\0'); }
    }

    private static void selectPartner(Properties profiles, String partnerId) {
        CONFIG.clear(); // Never retain a previous partner's secrets.
        if (partnerId == null || partnerId.trim().isEmpty()) throw new IllegalArgumentException("Partner ID is required");
        String prefix = "partner." + partnerId + ".";
        for (String name : profiles.stringPropertyNames()) {
            if (name.startsWith(prefix)) CONFIG.setProperty(name.substring(prefix.length()), profiles.getProperty(name));
        }
        if (property("MC_CONSUMER_KEY", "").isEmpty()) throw new IllegalArgumentException("Missing " + prefix + "MC_CONSUMER_KEY; no global or other-partner fallback is used");
        String[][] alternatives = {
                {"MC_SIGNING_PRIVATE_KEY_PEM", "MC_SIGNING_P12"},
                {"MC_DECRYPTION_PRIVATE_KEY_PEM", "MC_DECRYPTION_P12"},
                {"MC_ENCRYPTION_PUBLIC_KEY_PEM", "MC_ENCRYPTION_CERT"}
        };
        for (String[] pair : alternatives) {
            if (property(pair[0], "").isEmpty() && property(pair[1], "").isEmpty())
                throw new IllegalArgumentException("Set " + prefix + pair[0] + " or " + prefix + pair[1]);
        }
    }

    private static byte[] utf8(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static byte[] sha256(byte[] value) throws Exception { return MessageDigest.getInstance("SHA-256").digest(value); }
    private static String base64Url(byte[] value) { return Base64.getUrlEncoder().withoutPadding().encodeToString(value); }
    private static byte[] decode64Url(String value) { return Base64.getUrlDecoder().decode(value); }
    private static String percentEncode(String value) throws Exception { return URLEncoder.encode(value, "UTF-8").replace("+", "%20").replace("*", "%2A").replace("%7E", "~"); }
    private static String hex(byte[] value) { StringBuilder out = new StringBuilder(); for (byte b : value) out.append(String.format("%02x", b & 255)); return out.toString(); }
    private static String property(String key, String fallback) { String v = CONFIG.getProperty(key); return v == null || v.isEmpty() ? fallback : v; }
    private static String requiredProperty(String key) { String v = property(key, ""); if (v.isEmpty()) throw new IllegalArgumentException("Set property " + key); return v; }
    private static String readUtf8(InputStream input) throws Exception {
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static void selfTest() throws Exception {
        Properties profiles = new Properties();
        for (String id : Arrays.asList("PARTNER_A", "PARTNER_B")) {
            profiles.setProperty("partner." + id + ".MC_CONSUMER_KEY", id + "-consumer");
            profiles.setProperty("partner." + id + ".MC_SIGNING_P12", id + "-signing.p12");
            profiles.setProperty("partner." + id + ".MC_DECRYPTION_P12", id + "-decryption.p12");
            profiles.setProperty("partner." + id + ".MC_ENCRYPTION_CERT", id + ".pem");
        }
        profiles.setProperty("partner.PARTNER_A.MC_KEY_PASSWORD", "only-for-A");
        selectPartner(profiles, "PARTNER_A");
        if (!"PARTNER_A-consumer".equals(requiredProperty("MC_CONSUMER_KEY"))) throw new AssertionError("Wrong partner A");
        selectPartner(profiles, "PARTNER_B");
        if (!"PARTNER_B-consumer".equals(requiredProperty("MC_CONSUMER_KEY")) || !property("MC_KEY_PASSWORD", "").isEmpty()) throw new AssertionError("Partner credential leakage");
        profiles.setProperty("MC_CONSUMER_KEY", "global-must-not-be-used");
        try { selectPartner(profiles, "MISSING"); throw new AssertionError("Unknown partner accepted"); }
        catch (IllegalArgumentException expected) { /* correct */ }
        profiles.remove("partner.PARTNER_B.MC_SIGNING_P12");
        try { selectPartner(profiles, "PARTNER_B"); throw new AssertionError("Incomplete partner accepted"); }
        catch (IllegalArgumentException expected) { /* correct */ }
        CONFIG.clear();
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA"); generator.initialize(2048);
        KeyPair keys = generator.generateKeyPair();
        String original = "{\"message\":\"Unicode \u20ac and encryption\"}";
        String encrypted = encryptPayload(original, keys.getPublic(), "test-key");
        if (!original.equals(decryptResponse(encrypted, keys.getPrivate()))) throw new AssertionError("Round trip failed");
        JsonObject envelope = JsonParser.parseString(encrypted).getAsJsonObject();
        String[] parts = envelope.getAsJsonObject("encrypted_payload").get("data").getAsString().split("\\.");
        byte[] tag = decode64Url(parts[4]); tag[0] ^= 1; parts[4] = base64Url(tag);
        envelope.getAsJsonObject("encrypted_payload").addProperty("data", String.join(".", parts));
        try { decryptResponse(JSON.toJson(envelope), keys.getPrivate()); throw new AssertionError("Tampered tag accepted"); }
        catch (javax.crypto.AEADBadTagException expected) { /* correct */ }
        String error = "{\"Errors\":{\"Error\":[]}}";
        if (!error.equals(decryptResponse(error, keys.getPrivate()))) throw new AssertionError("Plaintext error changed");
        System.out.println("PASS: partner selection, credential isolation, missing/incomplete profile rejection, JWE round trip, Unicode, tampered-tag rejection, plaintext error handling.");
    }
}
