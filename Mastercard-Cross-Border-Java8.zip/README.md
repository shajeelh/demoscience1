# Java 8 Mastercard example — partner-specific properties

One properties file holds multiple partner profiles. The command-line partner ID selects both the credentials and the partner ID in the Mastercard request URL. There is no global or other-partner credential fallback.

## Properties format

Copy `mastercard.properties.example` to `mastercard.properties`. Replace PARTNER_A and PARTNER_B with your actual partner IDs:

```properties
partner.PARTNER_A.MC_CONSUMER_KEY=consumer-key-for-A
partner.PARTNER_A.MC_KEYS_DIR=C:/keys/partner-a
partner.PARTNER_A.MC_KEY_PASSWORD=password-for-A
partner.PARTNER_A.MC_SIGNING_P12=signing.p12
partner.PARTNER_A.MC_SIGNING_ALIAS=mastercardkey
partner.PARTNER_A.MC_ENCRYPTION_CERT=client-encryption.pem
partner.PARTNER_A.MC_DECRYPTION_P12=response-decryption.p12

partner.PARTNER_B.MC_CONSUMER_KEY=consumer-key-for-B
partner.PARTNER_B.MC_KEYS_DIR=C:/keys/partner-b
partner.PARTNER_B.MC_KEY_PASSWORD=password-for-B
partner.PARTNER_B.MC_SIGNING_P12=signing.p12
partner.PARTNER_B.MC_SIGNING_ALIAS=mastercardkey
partner.PARTNER_B.MC_ENCRYPTION_CERT=client-encryption.pem
partner.PARTNER_B.MC_DECRYPTION_P12=response-decryption.p12
```

Use UTF-8 and forward slashes for Windows paths. Relative key directories resolve beside the properties file. Each partner must specify its consumer key and either a file or PEM value for each of the three keys. Do not use the previous unprefixed properties format; it is no longer accepted.

## Run

```shell
java -jar MastercardCrossBorder.jar mastercard.properties PARTNER_A
java -jar MastercardCrossBorder.jar mastercard.properties PARTNER_B
```

The selected ID is used directly in `/send/v1/partners/{partner-id}/crossborder/quotes`. `MC_PARTNER_ID` is no longer needed.

Your existing sandbox credentials have been migrated to `partner.SANDBOX_1234567.*` in the local file:

```shell
java -jar MastercardCrossBorder.jar mastercard.local.properties SANDBOX_1234567
```

The local file contains private keys and is excluded from Git and the ZIP. The package includes only the blank two-partner template.

## Optional per-partner settings

All settings below require the same `partner.<ID>.` prefix:

- `MC_DECRYPTION_PASSWORD`: defaults to that partner's `MC_KEY_PASSWORD`.
- `MC_DECRYPTION_ALIAS`: blank selects the sole private key in the PKCS#12.
- `MC_ENCRYPTION_KEY_ID`: blank computes the SHA-256 SPKI fingerprint.
- `MC_TRANSACTION_REFERENCE`: blank generates a new quote reference.
- `MC_SIGNING_PRIVATE_KEY_PEM`, `MC_DECRYPTION_PRIVATE_KEY_PEM`, `MC_ENCRYPTION_PUBLIC_KEY_PEM`: complete PEM strings instead of key files, with literal `\n` line breaks. Private keys must be PKCS#8; public keys must be SPKI.

## Validate without calling Mastercard

```shell
java -jar MastercardCrossBorder.jar mastercard.properties PARTNER_A --check-config
java -jar MastercardCrossBorder.jar --self-test
```

The configuration check loads only the selected partner's keys. The self-test verifies profile selection, credential isolation, missing/incomplete profile rejection, JWE round trip, Unicode, tamper detection, and plaintext error handling.

To import a configured Postman environment into the local properties file:

```powershell
./run-from-postman.ps1 -EnvironmentFile C:/path/to/environment.json -CheckOnly
```

The helper uses that environment's partner ID (or an explicit `-PartnerId`), updates its section, and preserves other partner sections it previously wrote. Without `-CheckOnly`, it also sends a sandbox quote. It reads the adjacent configured Postman environment by default.

## Java example and build

`MastercardCrossBorder.java` remains one executable class. Edit `requestPayloadJson` in `main` for the request payload. The example encrypts and signs a sandbox quote and prints the decrypted response. It does not initiate a payment. The single-process CLI uses one selected profile per invocation; the static configuration is not a concurrent multi-tenant service API.

```shell
javac -cp gson-2.13.2.jar MastercardCrossBorder.java
jar cfm MastercardCrossBorder.jar MANIFEST.MF MastercardCrossBorder.class
```

On newer JDKs use `javac --release 8 -cp gson-2.13.2.jar MastercardCrossBorder.java`. Keep the application and Gson JARs together. Gson is the only external dependency. Use a maintained Java 8 update with AES-256 enabled.

This edition compiled for Java 8 and passed self-tests plus the existing sandbox profile's key-loading check. No live call was needed for the profile-selection change. Earlier encryption/signing/decryption logic passed an authenticated sandbox quote with HTTP 200. Testing used JDK 23 targeting Java 8 bytecode, not an installed Java 8 runtime.
