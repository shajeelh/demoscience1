param(
    [string]$EnvironmentFile = (Join-Path $PSScriptRoot '../Mastercard-Sandbox.configured.local.json'),
    [string]$PartnerId,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
$configuration = Get-Content -LiteralPath $EnvironmentFile -Raw | ConvertFrom-Json
$mapping = @{
    MC_CONSUMER_KEY = 'consumer_key'
    MC_SIGNING_PRIVATE_KEY_PEM = 'signing_private_key_pem'
    MC_DECRYPTION_PRIVATE_KEY_PEM = 'response_decryption_private_key_pem'
    MC_ENCRYPTION_PUBLIC_KEY_PEM = 'encryption_public_key_pem'
    MC_ENCRYPTION_KEY_ID = 'encryption_key_id'
}
if (!$PartnerId) { $PartnerId = ($configuration.values | Where-Object key -eq 'partner_id').value }
if (!$PartnerId -or $PartnerId -match '[\s=:\\]') { throw 'Provide a partner ID without whitespace, backslashes, equals signs or colons.' }
$propertiesFile = Join-Path $PSScriptRoot 'mastercard.local.properties'
$prefix = "partner.$PartnerId."
$lines = @('# Local credentials. Do not commit or share this file.')
if (Test-Path -LiteralPath $propertiesFile) {
    $lines += @(Get-Content -LiteralPath $propertiesFile | Where-Object { $_.StartsWith('partner.') -and !$_.StartsWith($prefix) })
}
foreach ($name in $mapping.Keys) {
    $value = ($configuration.values | Where-Object key -eq $mapping[$name]).value
    if (!$value) { throw "Missing Postman variable: $($mapping[$name])" }
    $escaped = $value.Replace('\', '\\').Replace("`r", '\r').Replace("`n", '\n').Replace("`t", '\t')
    $lines += "$prefix$name=$escaped"
}
[IO.File]::WriteAllLines($propertiesFile, $lines, [Text.UTF8Encoding]::new($false))
if ($CheckOnly) {
    & java -jar (Join-Path $PSScriptRoot 'MastercardCrossBorder.jar') $propertiesFile $PartnerId --check-config
} else {
    & java -jar (Join-Path $PSScriptRoot 'MastercardCrossBorder.jar') $propertiesFile $PartnerId
}
exit $LASTEXITCODE
